from persona import *
from instructor import *

person1=instructor(9, 700, 'centro deportivo', 'cr 14 S' , '25/08/2023', 49, 'Sheynna', 3152484, 45)
print(person1.get_informacion())
person2=instructor(2, 67, 'centro educativo', 'cr 89 S' , '12/01/2022', 48, 'Salome', 351526, 50)
print(person2.get_informacion())
person3=instructor(8, 721, 'institucion educativa', 'cr 4 S' , '305/05/2020', 49, 'Karen', 51515451, 5)
print(person3.get_informacion())
person4=instructor(3, 698, 'gym', 'cr 64 S' , '25/08/2021', 49, 'Sara', 854128, 4)
print(person4.get_informacion())
person5=instructor(9, 700, 'Sena', 'cr 89 S' , '26/05/1986', 46, 'Olga', 1585456, 75)
print(person5.get_informacion())

